package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
    int fil1,fil2,fil3,fil4,filsum,filtotal;
    int eng1,eng2,eng3,eng4,engsum,engtotal;
    int math1,math2,math3,math4,mathsum,mathtotal;
    int sci1,sci2,sci3,sci4,scisum,scitotal;
    int ap1,ap2,ap3,ap4,apsum,aptotal;
    int esp1,esp2,esp3,esp4,espsum,esptotal;
    int epp1,epp2,epp3,epp4,eppsum,epptotal;
    int mapeh1,mapeh2,mapeh3,mapeh4,mapehsum,mapehtotal;



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final EditText fil1st= (EditText) findViewById(R.id.fil1);
        final EditText fil2nd= (EditText) findViewById(R.id.fil2);
        final EditText fil3rd= (EditText) findViewById(R.id.fil3);
        final EditText fil4th= (EditText) findViewById(R.id.fil4);

        final EditText eng1st= (EditText) findViewById(R.id.eng1);
        final EditText eng2nd= (EditText) findViewById(R.id.eng2);
        final EditText eng3rd= (EditText) findViewById(R.id.eng3);
        final EditText eng4th= (EditText) findViewById(R.id.eng4);

        final EditText math1st= (EditText) findViewById(R.id.math1);
        final EditText math2nd= (EditText) findViewById(R.id.math2);
        final EditText math3rd= (EditText) findViewById(R.id.math3);
        final EditText math4th= (EditText) findViewById(R.id.math4);

        final EditText sci1st= (EditText) findViewById(R.id.sci1);
        final EditText sci2nd= (EditText) findViewById(R.id.sci2);
        final EditText sci3rd= (EditText) findViewById(R.id.sci3);
        final EditText sci4th= (EditText) findViewById(R.id.sci4);

        final EditText ap1st= (EditText) findViewById(R.id.ap1);
        final EditText ap2nd= (EditText) findViewById(R.id.ap2);
        final EditText ap3rd= (EditText) findViewById(R.id.ap3);
        final EditText ap4th= (EditText) findViewById(R.id.ap4);

        final EditText esp1st= (EditText) findViewById(R.id.esp1);
        final EditText esp2nd= (EditText) findViewById(R.id.esp2);
        final EditText esp3rd= (EditText) findViewById(R.id.esp3);
        final EditText esp4th= (EditText) findViewById(R.id.esp4);

        final EditText epp1st= (EditText) findViewById(R.id.epp1);
        final EditText epp2nd= (EditText) findViewById(R.id.epp2);
        final EditText epp3rd= (EditText) findViewById(R.id.epp3);
        final EditText epp4th= (EditText) findViewById(R.id.epp4);

        final EditText mapeh1st= (EditText) findViewById(R.id.fil1);
        final EditText mapeh2nd= (EditText) findViewById(R.id.fil2);
        final EditText mapeh3rd= (EditText) findViewById(R.id.fil3);
        final EditText mapeh4th= (EditText) findViewById(R.id.fil4);

        Button averagebutton = (Button) findViewById(R.id.button);
        averagebutton.setOnClickListener(new View.OnClickListener() {
            TextView filipinofinal = (TextView) findViewById(R.id.filfinal);
            TextView englishfinal = (TextView) findViewById(R.id.engfinal);
            TextView mathfinal = (TextView) findViewById(R.id.mathfinal);
            TextView sciencefinal = (TextView) findViewById(R.id.scifinal);
            TextView APfinal = (TextView) findViewById(R.id.apfinal);
            TextView ESPfinal = (TextView) findViewById(R.id.espfinal);
            TextView EPPfinal = (TextView) findViewById(R.id.eppfinal);
            TextView mapehfinal = (TextView) findViewById(R.id.mapehfinal);
            TextView Average = (TextView) findViewById(R.id.average);
            @Override
            public void onClick(View v) {
                fil1 = Integer.parseInt(fil1st.getText().toString());
                fil2 = Integer.parseInt(fil2nd.getText().toString());
                fil3 = Integer.parseInt(fil3rd.getText().toString());
                fil4 = Integer.parseInt(fil4th.getText().toString());

                eng1 = Integer.parseInt(eng1st.getText().toString());
                eng2 = Integer.parseInt(eng2nd.getText().toString());
                eng3 = Integer.parseInt(eng3rd.getText().toString());
                eng4 = Integer.parseInt(eng4th.getText().toString());

                math1 = Integer.parseInt(math1st.getText().toString());
                math2 = Integer.parseInt(math2nd.getText().toString());
                math3 = Integer.parseInt(math3rd.getText().toString());
                math4 = Integer.parseInt(math4th.getText().toString());

                sci1 = Integer.parseInt(sci1st.getText().toString());
                sci2 = Integer.parseInt(sci2nd.getText().toString());
                sci3 = Integer.parseInt(sci3rd.getText().toString());
                sci4 = Integer.parseInt(sci4th.getText().toString());

                ap1 = Integer.parseInt(ap1st.getText().toString());
                ap2 = Integer.parseInt(ap2nd.getText().toString());
                ap3 = Integer.parseInt(ap3rd.getText().toString());
                ap4 = Integer.parseInt(ap4th.getText().toString());

                esp1 = Integer.parseInt(esp1st.getText().toString());
                esp2 = Integer.parseInt(esp2nd.getText().toString());
                esp3 = Integer.parseInt(esp3rd.getText().toString());
                esp4 = Integer.parseInt(esp4th.getText().toString());

                epp1 = Integer.parseInt(epp1st.getText().toString());
                epp2 = Integer.parseInt(epp2nd.getText().toString());
                epp3 = Integer.parseInt(epp3rd.getText().toString());
                epp4 = Integer.parseInt(epp4th.getText().toString());

                mapeh1 = Integer.parseInt(mapeh1st.getText().toString());
                mapeh2 = Integer.parseInt(mapeh2nd.getText().toString());
                mapeh3 = Integer.parseInt(mapeh3rd.getText().toString());
                mapeh4 = Integer.parseInt(mapeh4th.getText().toString());

                filsum = fil1 + fil2 + fil3 + fil4;
                filtotal = filsum / 4;

                engsum = eng1 + eng2 + eng3 + eng3;
                engtotal = engsum / 4;

                mathsum = math1 + math2 + math3 + math4;
                mathtotal = mathsum / 4;

                scisum = sci1 + sci2 + sci3 + sci4;
                scitotal = scisum / 4;

                apsum = ap1 + ap2 + ap3 + ap4;
                aptotal = apsum / 4;

                espsum = esp1 + esp2 + esp3 + esp4;
                esptotal = espsum / 4;

                eppsum = epp1 + epp2 + epp3 + epp4;
                epptotal = eppsum / 4;

                mapehsum = mapeh1 + mapeh2 + mapeh3 +mapeh4;
                mapehtotal = mapehsum / 4;

                DecimalFormat currency = new DecimalFormat( "##");
                filipinofinal.setText(currency.format(filtotal));
                englishfinal.setText(currency.format(engtotal));
                mathfinal.setText(currency.format(mathtotal));
                sciencefinal.setText(currency.format(scitotal));
                APfinal.setText(currency.format(aptotal));
                ESPfinal.setText(currency.format(esptotal));
                EPPfinal.setText(currency.format(epptotal));
                mapehfinal.setText(currency.format(mapehtotal));
            }
        });



    }
}